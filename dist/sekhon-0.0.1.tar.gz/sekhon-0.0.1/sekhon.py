#!/usr/bin/env python

import random
import time


__version__ = "0.0.1"


def sekhon(a, b, c, d, samples=10000, tolerance=0.0, significance_level=0.95,
        ensure_convergence=True, ensure_samples=1000000, ensure_radius=0.007):
    successes = 0.0
    for i in xrange(0, samples):
        successes += random.betavariate(a + 1, b + 1) - random.betavariate(c + 1, d + 1) > tolerance

    result = successes / samples

    if abs(result - significance_level) < ensure_radius:
        result = sekhon(a, b, c, d, samples=ensure_samples, ensure_convergence=False)

    return result


def convergance_test(samples, trials):
    results = []
    for i in xrange(0, trials):
        results.append(sekhon(8, 250, 3, 250, samples))

    print "Min is", min(results)
    print "Max is", max(results)
    print "Range:", max(results) - min(results)


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=
            "Sekhon Fisher test for table [[a,c],[b,d]]")

    parser.add_argument('a', type=int)
    parser.add_argument('b', type=int)
    parser.add_argument('c', type=int)
    parser.add_argument('d', type=int)

    parser.add_argument('--samples', type=int, default=10000)

    args = parser.parse_args()


    a, b, c, d = [vars(args)[x] for x in ['a', 'b', 'c', 'd']]

    t0 = time.time()
    result = sekhon(a, b, c, d, args.samples)
    t1 = time.time()

    print "Ran", args.samples, "simulations in", t1 - t0, "seconds"
    print "Result is:", result

